package com.example.demojwt_security.user;

public enum Role {
}
