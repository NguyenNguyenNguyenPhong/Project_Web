package com.example.demojwt_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojwtSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
