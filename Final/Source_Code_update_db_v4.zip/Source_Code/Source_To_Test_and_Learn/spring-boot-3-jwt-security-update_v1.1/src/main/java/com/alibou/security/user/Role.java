package com.alibou.security.user;

public enum Role {

  USER,
  ADMIN
}
