//package com.alibou.security.dao;
//
//import com.alibou.security.entity.CourseTeach;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface CourseTeachRepository extends JpaRepository<CourseTeach, Integer> {
//    List<CourseTeach> findByTeacherId(int teacherId);
//}
//
