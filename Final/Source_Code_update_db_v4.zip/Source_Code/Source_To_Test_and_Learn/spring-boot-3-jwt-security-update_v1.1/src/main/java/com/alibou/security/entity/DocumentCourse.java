package com.alibou.security.entity;

import com.alibou.security.entity.Course;
import jakarta.persistence.*;

@Entity
@Table(name = "documentcourse")
public class DocumentCourse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "documentID")
    private int documentID;

    @Column(name = "cntdocument", nullable = false)
    private String cntDocument;

    @ManyToOne
    @JoinColumn(name = "courseID")
    private Course course;

    public DocumentCourse() {
    }

    public DocumentCourse(int documentID, String cntDocument, Course course) {
        this.documentID = documentID;
        this.cntDocument = cntDocument;
        this.course = course;
    }

    public int getDocumentID() {
        return documentID;
    }

    public void setDocumentID(int documentID) {
        this.documentID = documentID;
    }

    public String getCntDocument() {
        return cntDocument;
    }

    public void setCntDocument(String cntDocument) {
        this.cntDocument = cntDocument;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
