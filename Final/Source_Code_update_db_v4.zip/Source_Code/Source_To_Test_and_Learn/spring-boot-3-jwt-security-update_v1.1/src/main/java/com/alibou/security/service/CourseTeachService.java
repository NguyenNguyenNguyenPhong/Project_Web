//package com.alibou.security.service;
//
//import java.util.List;
//
//public interface CourseTeachService {
//    List<Integer> findCourseIdsByTeacherId(int teacherId);
//}